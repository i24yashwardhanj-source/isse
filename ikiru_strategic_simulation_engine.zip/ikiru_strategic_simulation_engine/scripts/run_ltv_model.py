import pandas as pd
from lifetimes import BetaGeoFitter, GammaGammaFitter
from lifetimes.utils import summary_data_from_transaction_data
from pathlib import Path

def run_ltv_analysis(processed_data_path: Path, reports_dir: Path):
    """
    Runs the full LTV analysis and saves the predictions.
    """
    # Load processed transactional data
    orders_df = pd.read_parquet(processed_data_path)

    # Create RFM dataframe
    rfm_df = summary_data_from_transaction_data(
        orders_df,
        customer_id_col='customer_id',
        datetime_col='order_date',
        monetary_value_col='order_value'
    )

    # --- BG/NBD Model ---
    bgf = BetaGeoFitter(penalizer_coef=0.0)
    bgf.fit(rfm_df['frequency'], rfm_df['recency'], rfm_df['T'])

    # --- Gamma-Gamma Model ---
    returning_customers = rfm_df[rfm_df['frequency'] > 0]
    ggf = GammaGammaFitter(penalizer_coef=0.0)
    ggf.fit(returning_customers['frequency'], returning_customers['monetary_value'])

    # --- CLV Calculation ---
    clv_forecast = ggf.customer_lifetime_value(
        bgf,
        rfm_df['frequency'],
        rfm_df['recency'],
        rfm_df['T'],
        rfm_df['monetary_value'],
        time=12,  # 12 months forecast
        discount_rate=0.01 # Monthly discount rate
    )

    rfm_df['predicted_clv_12_months'] = clv_forecast
    
    # Save results
    output_path = reports_dir / "customer_ltv_predictions.csv"
    rfm_df.to_csv(output_path)
    
    print("LTV Analysis Complete.")
    print(f"Full predictions saved to {output_path}")
    print("\nTop 10 Most Valuable Customers (next 12 months):")
    print(rfm_df.sort_values(by='predicted_clv_12_months', ascending=False).head(10))

