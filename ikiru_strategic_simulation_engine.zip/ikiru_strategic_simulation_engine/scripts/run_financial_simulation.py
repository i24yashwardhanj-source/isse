from pathlib import Path
from src.isse.models.financial_simulation import run_financial_simulation

if __name__ == "__main__":
    BASE_DIR = Path(__file__).resolve().parent.parent
    ASSUMPTIONS_PATH = BASE_DIR / "data/processed/financial_assumptions_data.parquet"
    LTV_PREDICTIONS_PATH = BASE_DIR / "reports/ltv_results/customer_ltv_predictions.csv"
    # Placeholder for B2B predictions once available
    B2B_PREDICTIONS_PATH = None
    REPORTS_DIR = BASE_DIR / "reports/financial_results"
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    run_financial_simulation(
        ASSUMPTIONS_PATH,
        LTV_PREDICTIONS_PATH,
        B2B_PREDICTIONS_PATH,
        REPORTS_DIR
    )

