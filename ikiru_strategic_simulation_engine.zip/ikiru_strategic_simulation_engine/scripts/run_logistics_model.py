from pathlib import Path
from src.isse.models.logistics_optimization import run_logistics_simulation

if __name__ == "__main__":
    BASE_DIR = Path(__file__).resolve().parent.parent
    CUSTOMERS_PATH = BASE_DIR / "data/processed/customer_locations_data.parquet"
    WAREHOUSES_PATH = BASE_DIR / "data/processed/warehouse_locations_data.parquet"
    REPORTS_DIR = BASE_DIR / "reports/logistics_results"
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    run_logistics_simulation(CUSTOMERS_PATH, WAREHOUSES_PATH, REPORTS_DIR)

