from pathlib import Path
from src.isse.models.b2b_win_probability import run_b2b_win_prob_analysis

if __name__ == "__main__":
    BASE_DIR = Path(__file__).resolve().parent.parent
    PROCESSED_DATA_PATH = BASE_DIR / "data/processed/b2b_pipeline_data.parquet"
    REPORTS_DIR = BASE_DIR / "reports/b2b_results"
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    run_b2b_win_prob_analysis(PROCESSED_DATA_PATH, REPORTS_DIR)

