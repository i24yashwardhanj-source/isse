from src.isse.io.loaders import process_all_data

if __name__ == "__main__":
    print("Starting data processing pipeline...")
    process_all_data()
    print("Data processing pipeline finished.")

