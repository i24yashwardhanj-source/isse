import pandas as pd
from lightweight_mmm import lightweight_mmm
from lightweight_mmm import plot
from lightweight_mmm import preprocessing
import jax.numpy as jnp
from pathlib import Path

def run_mmm_analysis(processed_data_path: Path, reports_dir: Path):
    """
    Runs the full MMM analysis and saves results.
    """
    df = pd.read_parquet(processed_data_path)
    df = df.set_index('date').resample('W').sum().reset_index() # Resample to weekly

    # Prepare data for the model
    target = df['total_sales'].values
    spend = df[['facebook_spend', 'google_spend', 'influencer_spend']].values
    
    # Split data
    split_point = len(df) - 12 # Reserve last 12 weeks for testing
    train_spend = spend[:split_point]
    train_target = target[:split_point]
    
    # Scale data
    spend_scaler = preprocessing.CustomScaler(multiply_by=jnp.mean(train_spend))
    target_scaler = preprocessing.CustomScaler(multiply_by=jnp.mean(train_target))
    
    scaled_train_spend = spend_scaler.transform(train_spend)
    scaled_train_target = target_scaler.transform(train_target)

    # --- Fit MMM ---
    mmm = lightweight_mmm.LightweightMMM(model_name="carryover")
    mmm.fit(
        media=scaled_train_spend,
        media_prior=jnp.array([0.05, 0.05, 0.05]), # Assume 5% cost of acquisition
        target=scaled_train_target,
        number_warmup=1000,
        number_samples=1000,
        number_chains=2
    )

    # --- Plot and Save Results ---
    fig = plot.plot_model_fit(mmm, target_scaler=target_scaler)
    fig.savefig(reports_dir / "mmm_model_fit.png")
    
    fig = plot.plot_media_channel_posteriors(media_mix_model=mmm, channel_names=['Facebook', 'Google', 'Influencer'])
    fig.savefig(reports_dir / "mmm_channel_posteriors.png")
    
    media_contribution, roi_hat = mmm.get_posterior_metrics(
        unscaled_costs=train_spend, 
        target_scaler=target_scaler
    )

    print("MMM Analysis Complete.")
    print("\nPosterior Media Contributions:")
    print(media_contribution.mean(axis=0))
    print("\nPosterior ROI:")
    print(roi_hat.mean(axis=0))
    print(f"Detailed plots saved to {reports_dir}")

