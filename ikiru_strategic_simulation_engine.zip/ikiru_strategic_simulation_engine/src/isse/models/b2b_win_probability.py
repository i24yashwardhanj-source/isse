import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

def run_b2b_win_prob_analysis(processed_data_path: Path, reports_dir: Path):
    """
    Trains a model to predict B2B deal win probability.
    """
    df = pd.read_parquet(processed_data_path)

    # Feature Engineering
    df_encoded = pd.get_dummies(df, columns=['lead_source', 'project_type'], drop_first=True)
    df_encoded['status'] = df_encoded['status'].apply(lambda x: 1 if x == 'Won' else 0)

    X = df_encoded.drop('status', axis=1)
    y = df_encoded['status']

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    # --- Train Model ---
    model = RandomForestClassifier(random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)

    # --- Evaluate Model ---
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]

    print("B2B Win Probability Model Evaluation:")
    print(classification_report(y_test, y_pred))
    print(f"ROC AUC Score: {roc_auc_score(y_test, y_pred_proba):.4f}")
    
    # Plot and save confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.savefig(reports_dir / "b2b_confusion_matrix.png")

    print(f"Confusion matrix plot saved to {reports_dir}")

