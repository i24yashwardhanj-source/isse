import pandas as pd
import osmnx as ox
import networkx as nx
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import folium
from pathlib import Path

def run_logistics_simulation(customers_path: Path, warehouses_path: Path, reports_dir: Path):
    """
    Finds the optimal warehouse and plans delivery routes for a single city.
    """
    CITY = "Mumbai, Maharashtra, India"
    NUM_VEHICLES = 4
    VEHICLE_CAPACITY = 15

    # --- Get Map Data (with caching) ---
    cache_path = Path('data/external/gis_cache/')
    cache_path.mkdir(parents=True, exist_ok=True)
    graph_path = cache_path / "mumbai.graphml"

    if graph_path.exists():
        G = ox.load_graphml(graph_path)
    else:
        G = ox.graph_from_place(CITY, network_type='drive')
        ox.save_graphml(G, graph_path)
    
    # --- Load Data ---
    customers_df = pd.read_parquet(customers_path)
    warehouses_df = pd.read_parquet(warehouses_path)
    
    # --- 1. Optimal Facility Location (Simplified) ---
    # Find warehouse with minimum average distance to customers
    avg_distances = {}
    for _, wh in warehouses_df.iterrows():
        wh_node = ox.nearest_nodes(G, wh['longitude'], wh['latitude'])
        total_dist = 0
        for _, cust in customers_df.iterrows():
            cust_node = ox.nearest_nodes(G, cust['longitude'], cust['latitude'])
            total_dist += nx.shortest_path_length(G, wh_node, cust_node, weight='length')
        avg_distances[wh['warehouse_id']] = total_dist / len(customers_df)

    optimal_warehouse_id = min(avg_distances, key=avg_distances.get)
    optimal_warehouse = warehouses_df[warehouses_df['warehouse_id'] == optimal_warehouse_id].iloc[0]
    print(f"Optimal Warehouse Location: {optimal_warehouse_id}")

    # --- 2. Dynamic Route Optimization (VRP) ---
    depot_node = ox.nearest_nodes(G, optimal_warehouse['longitude'], optimal_warehouse['latitude'])
    customer_nodes = [ox.nearest_nodes(G, lon, lat) for lon, lat in zip(customers_df['longitude'], customers_df['latitude'])]
    
    # Create distance matrix
    locations = [depot_node] + customer_nodes
    dist_matrix = {}
    for from_node in locations:
        dist_matrix[from_node] = {}
        for to_node in locations:
            dist_matrix[from_node][to_node] = nx.shortest_path_length(G, from_node, to_node, weight='length')

    node_map = {node: i for i, node in enumerate(locations)}
    inv_node_map = {i: node for node, i in node_map.items()}
    
    matrix = [[dist_matrix[inv_node_map[i]][inv_node_map[j]] for j in range(len(locations))] for i in range(len(locations))]

    # OR-Tools VRP Solver
    manager = pywrapcp.RoutingIndexManager(len(matrix), NUM_VEHICLES, 0)
    routing = pywrapcp.RoutingModel(manager)

    def distance_callback(from_index, to_index):
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return matrix[from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
    
    # Add capacity constraints
    def demand_callback(from_index):
        return 1
    demand_callback_index = routing.RegisterUnaryTransitCallback(demand_callback)
    routing.AddDimension(demand_callback_index, 0, VEHICLE_CAPACITY, True, 'Capacity')
    
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
    solution = routing.SolveWithParameters(search_parameters)

    # --- 3. Visualize and Save Routes ---
    m = folium.Map(location=[optimal_warehouse['latitude'], optimal_warehouse['longitude']], zoom_start=12)
    colors = ['red', 'blue', 'green', 'purple', 'orange']

    for vehicle_id in range(NUM_VEHICLES):
        index = routing.Start(vehicle_id)
        route_nodes = []
        while not routing.IsEnd(index):
            node_idx = manager.IndexToNode(index)
            route_nodes.append(inv_node_map[node_idx])
            index = solution.Value(routing.NextVar(index))
        route_nodes.append(inv_node_map[manager.IndexToNode(index)])
        
        if len(route_nodes) > 2: # Has deliveries
            route_latlongs = [(G.nodes[node]['y'], G.nodes[node]['x']) for node in route_nodes]
            folium.PolyLine(route_latlongs, color=colors[vehicle_id % len(colors)], weight=2.5, opacity=1).add_to(m)
            # Add customer markers
            for node in route_nodes[1:-1]:
                folium.Marker([G.nodes[node]['y'], G.nodes[node]['x']], popup=f"Customer").add_to(m)

    folium.Marker(
        [optimal_warehouse['latitude'], optimal_warehouse['longitude']],
        popup="Optimal Warehouse",
        icon=folium.Icon(color='black', icon='home')
    ).add_to(m)
    
    output_path = reports_dir / "optimized_delivery_routes.html"
    m.save(str(output_path))
    print(f"Logistics Simulation Complete. Interactive map saved to {output_path}")

