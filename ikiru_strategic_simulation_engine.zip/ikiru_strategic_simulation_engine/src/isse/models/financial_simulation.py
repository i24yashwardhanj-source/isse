import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

def run_financial_simulation(
    assumptions_path: Path,
    ltv_predictions_path: Path,
    b2b_predictions_path: Path,
    reports_dir: Path
):
    """
    Runs a Monte Carlo simulation to forecast 5-year financials.
    """
    assumptions = pd.read_parquet(assumptions_path).set_index('parameter')['value']

    # --- Load previous model outputs ---
    # In a real scenario, these would be live outputs. For now, we use them to inform assumptions.
    # ltv_df = pd.read_csv(ltv_predictions_path)
    # b2b_df = # We'd load the b2b model to get win probability
    
    # --- Set Simulation Parameters ---
    n_sims = int(assumptions.get('num_monte_carlo_simulations', 1000))
    n_years = int(assumptions.get('forecast_years', 5))
    discount_rate = assumptions.get('discount_rate_annual', 0.15)
    initial_investment = assumptions.get('initial_investment_inr', 250000000)

    # --- Run Monte Carlo Simulation ---
    results = []
    
    # Placeholder base revenues and costs. In a full model, these would be derived
    # from detailed unit economic forecasts from other modules.
    base_d2c_revenue = 52600000  # From presentation slide
    base_b2b_revenue = 35600000  # From presentation slide
    base_cogs_pct = 0.73 # From (1 - Gross Profit / Revenue)
    base_opex = 30000000 # Estimate

    for i in range(n_sims):
        d2c_rev_growth = np.random.normal(assumptions['d2c_growth_mean'], assumptions['d2c_growth_std'], n_years)
        b2b_rev_growth = np.random.normal(assumptions['b2b_growth_mean'], assumptions['b2b_growth_std'], n_years)

        d2c_revenues = [base_d2c_revenue * np.prod(1 + d2c_rev_growth[:y+1]) for y in range(n_years)]
        b2b_revenues = [base_b2b_revenue * np.prod(1 + b2b_rev_growth[:y+1]) for y in range(n_years)]
        
        total_revenues = np.array(d2c_revenues) + np.array(b2b_revenues)
        cogs = total_revenues * base_cogs_pct
        gross_profit = total_revenues - cogs
        opex = np.array([base_opex * (1.15**y) for y in range(n_years)]) # Assume opex grows 15% YoY
        
        ebitda = gross_profit - opex
        
        # Simple NPV calculation
        cash_flows = ebitda # Proxy for cash flow
        npv = np.npv(discount_rate, [-initial_investment] + list(cash_flows))
        
        results.append({
            'simulation_id': i,
            'npv': npv,
            'year_5_revenue': total_revenues[-1],
            'year_5_profit': ebitda[-1]
        })

    results_df = pd.DataFrame(results)
    
    # --- Display and Save Results ---
    print("Financial Simulation Complete.")
    print("\n--- Key Financial Projections (Median Outcome) ---")
    print(f"Projected 5-Year NPV: {results_df['npv'].median():,.0f} INR")
    print(f"Projected Year 5 Revenue: {results_df['year_5_revenue'].median():,.0f} INR")
    print(f"Projected Year 5 EBITDA: {results_df['year_5_profit'].median():,.0f} INR")

    print("\n--- Risk Analysis ---")
    print(f"Probability of Positive NPV: {(results_df['npv'] > 0).mean():.2%}")
    print(f"25th Percentile NPV: {results_df['npv'].quantile(0.25):,.0f} INR")
    print(f"75th Percentile NPV: {results_df['npv'].quantile(0.75):,.0f} INR")

    # Plot and save NPV distribution
    plt.figure(figsize=(10, 6))
    sns.histplot(results_df['npv'], bins=50, kde=True)
    plt.title('Distribution of Net Present Value (NPV) from Monte Carlo Simulation')
    plt.xlabel('NPV (in INR)')
    plt.ylabel('Frequency')
    plt.axvline(results_df['npv'].median(), color='red', linestyle='--', label=f"Median NPV: {results_df['npv'].median():,.0f}")
    plt.legend()
    plt.savefig(reports_dir / "npv_distribution.png")

    print(f"\nNPV distribution plot saved to {reports_dir}")

