import pandas as pd
import yaml
from pathlib import Path
from typing import Dict, Any, List, Type
from pydantic import ValidationError

from src.isse.io.schemas import (
    TransactionalSchema, MarketingSpendSchema, B2BPipelineSchema,
    CustomerLocationsSchema, WarehouseLocationsSchema, FinancialAssumptionsSchema
)

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = BASE_DIR / "configs/data_mapping.yaml"

def load_config() -> Dict[str, Any]:
    """Loads the data mapping configuration file."""
    with open(CONFIG_PATH, 'r') as f:
        return yaml.safe_load(f)

def validate_and_load_data(
    file_path: Path,
    schema: Type[BaseModel],
    columns_map: Dict[str, str]
) -> pd.DataFrame:
    """
    Loads a CSV, renames columns based on the config, validates against a Pydantic schema,
    and returns a clean DataFrame.
    """
    if not file_path.exists():
        print(f"Warning: Data file not found at {file_path}. Skipping.")
        return pd.DataFrame()

    df = pd.read_csv(file_path)
    
    # Rename columns to standardized names for validation
    inverted_map = {v: k for k, v in columns_map.items()}
    df = df.rename(columns=inverted_map)

    # Validate each row
    validated_records = []
    for index, row in df.iterrows():
        try:
            validated_records.append(schema(**row.to_dict()).dict())
        except ValidationError as e:
            print(f"Validation error in {file_path.name} at row {index}: {e}")
            continue
    
    clean_df = pd.DataFrame(validated_records)
    
    # Convert date columns
    for col in clean_df.columns:
        if 'date' in col:
            clean_df[col] = pd.to_datetime(clean_df[col])
            
    print(f"Successfully loaded and validated {len(clean_df)} rows from {file_path.name}.")
    return clean_df


def process_all_data():
    """Main function to process all datasets defined in the config."""
    config = load_config()
    processed_dir = BASE_DIR / 'data' / 'processed'
    processed_dir.mkdir(exist_ok=True)

    data_map = {
        'transactional_data': TransactionalSchema,
        'marketing_spend_data': MarketingSpendSchema,
        'b2b_pipeline_data': B2BPipelineSchema,
        'customer_locations_data': CustomerLocationsSchema,
        'warehouse_locations_data': WarehouseLocationsSchema,
        'financial_assumptions_data': FinancialAssumptionsSchema,
    }

    for key, schema in data_map.items():
        if key in config:
            file_info = config[key]
            raw_path = BASE_DIR / file_info['path']
            
            df = validate_and_load_data(raw_path, schema, file_info['columns'])
            
            if not df.empty:
                processed_path = processed_dir / f"{key}.parquet"
                df.to_parquet(processed_path, index=False)
                print(f"Saved processed data to {processed_path}")

if __name__ == '__main__':
    process_all_data()

