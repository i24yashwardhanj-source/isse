from pydantic import BaseModel, Field
from datetime import datetime

class TransactionalSchema(BaseModel):
    customer_id: str = Field(..., alias='Customer ID')
    order_date: datetime = Field(..., alias='Order Date')
    order_value: float = Field(..., alias='Grand Total')

class MarketingSpendSchema(BaseModel):
    date: datetime = Field(..., alias='Date')
    facebook_spend: float = Field(..., alias='Facebook Ads')
    google_spend: float = Field(..., alias='Google Ads')
    influencer_spend: float = Field(..., alias='Influencer Marketing')
    total_sales: float = Field(..., alias='Total Sales')

class B2BPipelineSchema(BaseModel):
    lead_source: str = Field(..., alias='Lead Source')
    deal_value: float = Field(..., alias='Deal Value (INR)')
    project_type: str = Field(..., alias='Project Type')
    status: str = Field(..., alias='Status')

class CustomerLocationsSchema(BaseModel):
    customer_id: str
    latitude: float
    longitude: float

class WarehouseLocationsSchema(BaseModel):
    warehouse_id: str
    latitude: float
    longitude: float
    
class FinancialAssumptionsSchema(BaseModel):
    parameter: str
    value: float
    description: str

